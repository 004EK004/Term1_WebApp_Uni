import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import GreetingElement from './myGreetingApp';
import GreetingElementwithProp from './mygreetingprop';
import AppColor from './appbackground';


import reportWebVitals from './reportWebVitals';
ReactDOM.render(
 <React.StrictMode>
 <GreetingElement/>
 </React.StrictMode>,
 document.getElementById('root')
);
ReactDOM.render(
  <React.StrictMode>
      <GreetingElementwithProp msg='Hi its Monday.' />
      <GreetingElementwithProp msg='Welcome User' />
      <GreetingElementwithProp msg='It is Monday' />
      <GreetingElementwithProp msg='It is Tuesday' />
      <GreetingElementwithProp msg='It is Wednesday' />
      <GreetingElementwithProp msg='It is Thursday' />
      <GreetingElementwithProp msg='It is Friday' />
      <GreetingElementwithProp msg='It is Saturday' />
      <GreetingElementwithProp msg='It is Sunday' />
  </React.StrictMode>,
  document.getElementById('root')
);
ReactDOM.render(
  <React.StrictMode>
        <AppColor heading="This is first element" lbl="Name :" color="Green" />
        <AppColor heading="This is second element" lbl="Name :" color="Blue" />
        <AppColor heading="This is third element" lbl="Name :" color="Yellow" />
  </React.StrictMode>,
  document.getElementById('root') // Attach to the root element in the HTML
);
reportWebVitals();

