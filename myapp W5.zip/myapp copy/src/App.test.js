import { render, screen } from '@testing-library/react';
import App from './App';
// setupTests.js
import '@testing-library/jest-dom';

test('renders hello link', () => {
  render(<App />);
  const linkElement = screen.getByText(/hello/i);
  expect(linkElement).toBeInTheDocument();
});
