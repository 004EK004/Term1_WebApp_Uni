//By Eric Kopy
import './App.css';   

function GreetingElement() {
    const greeting = 'Hello Lets start learning function Component...';
    
    return (
        <div className="App">
            <h1>{greeting}</h1>
        </div>
    );
}

export default GreetingElement;
