import React from 'react'; // Importing React
import './App.css'; // Importing the desired CSS style.

// Functional component 
function AppColor(props) {
  
    function greetUser(e) {
        // Change the background color based on the button clicked
        document.body.style.background = e.target.value;

        // Once "Enter" is pressed this message will appear.
        alert("Welcome, this is the colour " + document.getElementById(props.color).value);
    }

    // Return the JSX for rendering the component
    return (    // Possesses the background colour
        <div style={{ backgroundColor: 'blue', color: 'black', padding: '20px' }}>
            <h1>{props.heading}</h1>
            <p style={{ color: 'blue', fontSize: '30px', fontFamily: 'Arial' }}> 
             
            </p>
            <label className="label" id="lbl">{props.lbl}</label>
            <input id={props.color} type="text" />
            <button value={props.color} onClick={greetUser}>
                Colour me {props.color}
            </button>
        </div>
    );
}

export default AppColor; // Exporting the component

