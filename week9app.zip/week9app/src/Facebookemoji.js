import './App.css'; // Import the CSS from the CSS file.
import React from 'react';
import Like from './Like.png'; // Import each of the images used.
import Love from './Love.png';
import Smile from './Smile.png';

class FacebookEmojiCounter extends React.Component { // Classs for the Facebook Emoji Counter.
  constructor(props) {
    super(props);
    this.state = { number: 0 }; // Initial state
    this.increment = this.increment.bind(this); // Bind increment function
    this.pic = null;

    // Determine the image based on the `type` prop
    if (this.props.type === "Love") {
      this.pic = Love;
    } else if (this.props.type === "Like") {
      this.pic = Like;
    } else if (this.props.type === "happy") {
      this.pic = Smile;
    }
  }

  increment() {
    // Increment the state variable
    this.setState((prevState) => ({
      number: prevState.number + 1,
    }));
  }

  render() {
    return (
      <div>
        <h5>
          It is {this.state.number} {this.props.type}.
        </h5>
        <button onClick={this.increment}>
          <img src={this.pic} alt={this.props.type} />
          <b>{this.state.number}</b>
        </button>
      </div>
    );
  }
}

export default FacebookEmojiCounter;  // Export, which will allow me to use this component in either App.js or the Index file.

