import './App.css';
import React from 'react';
import Like from './Like.png';  // Assures  this image exists in the src folder
import Smile from './Smile.png';  // Assures this image exists in the src folder

class ToggleMode extends React.Component {  // Toggle mode class.
  constructor(props) {
    super(props);
    this.state = { pic: Smile };  // Default to 'Smile' image
    this.Toggle_Mode = this.Toggle_Mode.bind(this);
  }

  // Toggle between Like and Happy images when button is clicked
  Toggle_Mode() {
    this.setState((prevState) => ({
      pic: prevState.pic === Like ? Smile : Like,  // If pic is 'Like', change to 'Happy' and vice versa
    }));
  }

  render() {
    return (
      <div>
        <h3>This is output of Task2: {this.state.pic === Like ? "Like" : "Happy"}</h3>
        <button onClick={this.Toggle_Mode}>
          <img src={this.state.pic} alt="Toggle emoji" />
        </button>
      </div>
    );
  }
}

export default ToggleMode;
