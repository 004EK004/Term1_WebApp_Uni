import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import FacebookEmojiCounter from './Facebookemoji';  // Import the Facebook EmojiCounter.
import ToggleMode from './ToggleMode';  // Import the ToggleMode component

ReactDOM.render(
  <React.Fragment>
    <FacebookEmojiCounter type="Like" />
    <FacebookEmojiCounter type="Love" />
    <ToggleMode />  {/* Render the ToggleMode component */}
  </React.Fragment>,
  document.getElementById('root')
);



