//By Eric-u2483667


const number = parseInt(prompt("Enter a number: "));
// checks if the number is greater than zero. 
if (number > 0) {
 console.log("The number is positive");
}
// checks if number is 0
else if (number == 0) {
 console.log("The number is zero");
}
// Action peformed if number is less than zero.
else {
 console.log("The number is negative"); 
}
