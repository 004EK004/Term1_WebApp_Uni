//By Eric Kopy u2483667
console.log("This is my first program");  // Outputs the message "This is my first program"
console.log("Welcome John, your monthly salary is 500000");  // Outputs the message "Welcome John, your monthly salary is 500000"
