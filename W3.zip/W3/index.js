// Eric Kopy- EmployeeTask
function Employeeinfo(name, salary) {   // Function for the console to include employee name and salary.
    console.log("Employee Name: " + name);
    console.log("Employee Salary: £" + salary);
}
console.log("This is my first program") // Tells the terminal to write the text.

// Call the function with different values
Employeeinfo("John Smith", 50000); // Number represents the salary.

