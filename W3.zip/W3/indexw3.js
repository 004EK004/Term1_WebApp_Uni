// Eric Kopy- u2483667
// Function to display employee information
function Employeeinfo(name, salary) {
    console.log("Employee Name: " + name);
    console.log("Employee Salary: £" + salary);
}

console.log("This is my first program"); // prints out the text in the brackets

// Call the Employeeinfo function
Employeeinfo("John Smith", 50000); // salary also included.

// Arrow function.
const EmpSkills = (skills) => {
    console.log("Expert in " + skills); // Writes "Expert in" the console log.
}

EmpSkills("Java");

//Import the StudentInfo module
const StudentInfo = require('./StudentInfo'); // Ensures the correct path.

// Import the Person module
const Person = require('./Person'); // Using path to the person module.


console.log("Student Name: " + StudentInfo.getStudentName()); // Gets the student name
console.log("Campus Name: " + StudentInfo.getCampusName()); // Added to log campus name

// Details about the person including name, age and email.
const personDetails = new Person("Jane Smith", 25, "jane.smith@example.com");

console.log("Person Name: " + personDetails.getPersonInfo().Name); // Writes out Personal name.
console.log("Person Age: " + personDetails.getPersonInfo().Age); // Gets the persons age.
console.log("Person Email: " + personDetails.getPersonInfo().Email); // Personal Email.


// Task 4
os=require("os")
const util=require('util')
console.log("temporary directory"+ os.tmpdir() )
console.log("hostname: "+ os.hostname())
console.log("OS : " + os.platform() +"release:"+ os.release())
console.log("Uptime"+ (os.uptime())/3600 +" hours")
console.log("userInfo" + util.inspect(os.userInfo()))
console.log("Memory "+ os.totalmem()/1000000000 + "Giga byte")
console.log(" free: "+os.freemem()/1000000000 + "Giga byte")
console.log("CPU "+ util.inspect(os.cpus()))
console.log("Network"+ util.inspect(os.networkInterfaces()))
console.log("programe end")
