import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import Calculator from './calc'; // Importing the Calculator component from calc.js


// Create the root and render the Calculator component
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Calculator />
  </React.StrictMode>
);

