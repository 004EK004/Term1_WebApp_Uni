// Created by Eric Kopy u2483667

import './App.css';
import React from 'react';
import Calculator from './calc'; // Importing the Calculator component from calc.js


function App() {
  return (
    <div className="App">
      <h1>Calculator App</h1>
      <Calculator />
    </div>
  );
}

export default App;

