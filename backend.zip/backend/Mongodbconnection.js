//By u2483667
// Import the mongoose package
const mongoose = require('mongoose');

// MongoDB connection string including the database name 'BooksData'
const MONG_URI = 'mongodb://localhost:27017/BooksData';

// Establish connection to MongoDB with the updated configurations
mongoose.connect(MONG_URI, {
    useUnifiedTopology: true, // Enables the new server discovery and monitoring engine
    useNewUrlParser: true,   // Allows parsing of MongoDB connection strings correctly
})
    .then(() => console.log('Successfully connected to MongoDB at: ' + MONG_URI))
    .catch((err) => console.error('Error occurred while connecting to MongoDB: ', err));

// Get the connection instance
const db = mongoose.connection;

// Handle connection error
db.on('error', (err) => {
    console.error('Error occurred on MongoDB connection: ', err);
});

// Export the database connection
module.exports = db;

