// Import required packages and modules
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('./Mongodbconnection'); // Import MongoDB connection
const Books = require('./BookSchema'); // Mongoose schema for books

// Initialize the Express application
const app = express();

// Middleware to parse incoming request data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Enable CORS for cross-origin requests
app.use(cors());

// Default route for testing server
app.get('/', function (req, res) {
    res.send('Welcome to the Books Library API!');
});

// Route to fetch all books
app.get('/allbooks', function (req, res) {
    Books.find(function (err, allBooks) {
        if (err) {
            console.error(err);
            res.status(500).send('Error retrieving books');
        } else {
            res.json(allBooks);
        }
    });
});

// Route to fetch a single book by ID
app.get('/getbook/:id', function (req, res) {
    let id = req.params.id;
    Books.findById(id, function (err, book) {
        if (err) {
            console.error(err);
            res.status(500).send('Error retrieving the book');
        } else {
            res.json(book);
        }
    });
});

// Route to add a new book
app.post('/addbooks', function (req, res) {
    let newBook = new Books(req.body);
    newBook
        .save()
        .then(() => {
            res.status(200).json({ message: 'Book added successfully!' });
        })
        .catch((err) => {
            console.error(err);
            res.status(400).send('Failed to add the book');
        });
});

// Route to update a book by ID
app.post('/updatebook/:id', function (req, res) {
    let id = req.params.id;
    Books.findByIdAndUpdate(
        id,
        req.body, // Updated data from the request body
        { new: true }, // Option to return the updated document
        function (err, updatedBook) {
            if (err) {
                console.error(err);
                res.status(500).send('Failed to update the book');
            } else {
                res.status(200).json({ message: 'Book updated successfully!', updatedBook });
            }
        }
    );
});

// Route to delete a book by ID
app.post('/deleteBook/:id', function (req, res) {
    let id = req.params.id;
    Books.findByIdAndDelete(id, function (err) {
        if (err) {
            console.error(err);
            res.status(500).send('Failed to delete the book');
        } else {
            res.status(200).send('Book deleted successfully');
        }
    });
});

// Start the server on port 5000
app.listen(5000, function () {
    console.log('Server is running on port 5000');
});
