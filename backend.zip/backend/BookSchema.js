//BookSchema File
let mongoose = require('mongoose');

const BooksScheme = new mongoose.Schema({
    bookname: {
        type: String,
        required: true
    },
    pubyear: Number,
    Title: String,
    Topic: String
});
const Book = require('./path/to/bookModel'); 
// Used this area to practice.
const newBook = new Book({
    title: "To Kill a Mockingbird",
    author: "Harper Lee",
    publishedYear: 1965,
    genre: "Fiction"
});

newBook.save()
    .then(() => console.log("Book saved successfully!")) // console log message.
    .catch((err) => console.error("Error saving book: ", err));


module.exports = mongoose.model('abcmodel', BooksScheme, 'BookCollection');
