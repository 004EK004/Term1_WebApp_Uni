// Created By Eric Kopy
import React, { useState } from 'react';

const EmojiDisplay = () => {
  const [inputValue, setInputValue] = useState('');
// Defines the object
  const emojiMap = {
    happy:'😊',  //Selection of emojis
    like:'👍',
    upset:'😢',
  };
// Determines the emoji to display based on the current input value
  const displayedEmoji = emojiMap[inputValue.toLowerCase()] || '❓';

  // Handles any input change.
  const handleChange = (event) => {   
    setInputValue(event.target.value);
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h2>Emoji Display</h2>  
      <input
        type="text"
        value={inputValue}
        onChange={handleChange}
        placeholder="Type 'Happy', 'Like', or 'Sad'"
        style={{ padding: '10px', fontSize: '16px' }}
      />
      <div style={{ marginTop: '20px', fontSize: '50px' }}>
        {displayedEmoji}
      </div>
    </div>
  );
};

export default EmojiDisplay;  // The export default will be used in the importation of the component.
