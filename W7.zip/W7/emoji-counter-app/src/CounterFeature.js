
import React, { useState } from 'react';

function CounterFeature() {
  // useState hook to keep track of the count
  const [count, setCount] = useState(0);

  // Function to handle button click and update the count
  const handleClick = () => {
    setCount(count + 1);
  };

  return (
    <div className="App-header">
      <h1>Click Count: {count}</h1>
      {/* Button is hook-controlled, using onClick to update count state */}
      <button type="button" onClick={handleClick}>
        Click Me
      </button>
    </div>
  );
}

export default CounterFeature;
