
import React from 'react';



function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Welcome to My React App</h1>
        <p>This is a simple React app template.</p>
        
       
      </header>
    </div>
  );
}

export default App;
