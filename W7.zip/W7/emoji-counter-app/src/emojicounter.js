/*  Created by Eric Kopy u2483667  */
import React, { useState } from "react";
import Love from "./Love.png";
import Sad from "./Sad.png";
import Like from "./Like.png";

function EmojeeCounter() {    /* Function for the emoji counter, I have included all three images.   */
  
  const [loveCount, setLoveCount] = useState(0);
  const [likeCount, setLikeCount] = useState(0);
  const [sadCount, setSadCount] = useState(0);

  // Click handlers for each emoji to increment its count
  const handleLoveClick = () => {
    setLoveCount(loveCount + 1);
    console.log("Love count is now:", loveCount + 1);
  };

  const handleLikeClick = () => {
    setLikeCount(likeCount + 1);
    console.log("Like count is now:", likeCount + 1);
  };

  const handleSadClick = () => {
    setSadCount(sadCount + 1);
    console.log("Sad count is now:", sadCount + 1);
  };

  return (
    <div className="emoji-container">
      <h1>Emoji Counter</h1>

      <div className="emoji-item">
        <img
          src={Love}
          alt="Love"
          onClick={handleLoveClick}
          style={{ cursor: "pointer", width: "50px", height: "50px" }}
        />
        <p>
          Love Count: <span className="count-text">{loveCount}</span>
        </p>
      </div>

      <div className="emoji-item">
        <img
          src={Like}
          alt="Like"
          onClick={handleLikeClick}
          style={{ cursor: "pointer", width: "50px", height: "50px" }}
        />
        <p>
          Like Count: <span className="count-text">{likeCount}</span>
        </p>
      </div>

      <div className="emoji-item">
        <img
          src={Sad}
          alt="Sad"
          onClick={handleSadClick}
          style={{ cursor: "pointer", width: "50px", height: "50px" }}
        />
        <p>
          Sad Count: <span className="count-text">{sadCount}</span>
        </p>
      </div>
    </div>
  );
}

export default EmojeeCounter;
