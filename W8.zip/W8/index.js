// Created by Eric Kopy u2483667
// Please note that I have included all the tasks here to save space and storage otherwise Github will say that my file is far too big.

// Adding in Mongoose
const mongoose = require('mongoose');

// MongoDB Atlas connection string, Connects to my desired cluster.
const MONGO_URI = 'mongodb+srv://EK4:U20@cluster0.gph9e.mongodb.net/week8?retryWrites=true&w=majority';

// Connect to MongoDB Atlas using Mongoose
mongoose.connect(MONGO_URI, { useUnifiedTopology: true, useNewUrlParser: true })
  .then(() => console.log(`Connected to MongoDB Atlas`))  // notifies that I am connected to MongoDB Atlas.
  .catch((err) => console.error(`Error occurred during connection: ${err}`));

// Event listeners for the connection
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'Connection error:'));
db.once('open', () => {
  console.log('Database connected successfully.');
});

// Define the Schema
const PersonSchema = new mongoose.Schema({
  name: { type: String, required: true },
  age: Number,
  gender: String,
  salary: Number
});


const person_doc = mongoose.model('person_doc', PersonSchema, 'personCollection');

// Task 2: Insert multiple documents
const manypersons = [
  { name: 'Simon', age: 42, gender: "Male", salary: 3456 },
  { name: 'Neesha', age: 23, gender: "Female", salary: 1000 },
  { name: 'Mary', age: 27, gender: "Female", salary: 5402 },
  { name: 'Mike', age: 40, gender: "Male", salary: 4519 }
];

person_doc.insertMany(manypersons)
  .then(() => console.log("Data inserted successfully."))
  .catch((error) => console.log("Error inserting data:", error));

// Task 3: Fetch data
//  Fetch all documents and limit to 5
person_doc.find({})
  .limit(5)
  .then(docs => {
    console.log("Task 3: All documents (limited to 5):");
    console.log(docs);
  })
  .catch(err => console.error("Error fetching documents:", err));

//  Fetch documents with filtering criteria (e.g., age > 30)
const givenage = 30;
person_doc.find({ gender: "Female", age: { $gte: givenage } })
  .sort({ salary: 1 }) // Sort by salary in ascending order
  .select('name salary age') // Select only specific fields
  .limit(10) // Limit results to 10
  .exec()
  .then(docs => {
    console.log(`Task 3: Females with age >= ${givenage}:`);
    docs.forEach(doc => console.log(`Name: ${doc.name}, Age: ${doc.age}, Salary: ${doc.salary}`));
  })
  .catch(err => console.error("Error fetching filtered data:", err));

// Task5: Count total documents
person_doc.countDocuments()
  .exec()
  .then(count => {
    console.log("Task 5: Total documents count:", count);// outputs the result in the terminal.
  })
  .catch(err => console.error("Error counting documents:", err));

// Task6:Delete documents where age > 25
person_doc.deleteMany({ age: { $gte: 25 } })
  .exec()
  .then(docs => {
    console.log("Task 6: Deleted documents:");
    console.log(docs);
  })
  .catch(error => console.error("Error deleting documents:", error));

// Task7: Update all the documents where the gender is Female and set salary to 5555
person_doc.updateMany({ gender: "Female" }, { $set: { salary: 5555 } })
  .exec()
  .then(docs => {
    console.log("Task 7:Updated documents:"); // writes out message in the console log.
    console.log(docs);
  })
  .catch(error => console.error("Error updating documents:", error));

